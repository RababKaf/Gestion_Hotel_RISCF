package MODEL;


	public class LigneFacture {

		private double prixReservation;

		public LigneFacture(){

		}
}
