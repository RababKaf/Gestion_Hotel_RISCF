package MODEL;


	public class DetailReservationCh {

		private int nbrAdultes;
		private int nbrEnfants;
		public int m_Reservation;
		public int m_Categorie;

		public DetailReservationCh(){

		}

		public int getNbrAdultes() {
			return nbrAdultes;
		}

		public void setNbrAdultes(int nbrAdultes) {
			this.nbrAdultes = nbrAdultes;
		}

		public int getNbrEnfants() {
			return nbrEnfants;
		}

		public void setNbrEnfants(int nbrEnfants) {
			this.nbrEnfants = nbrEnfants;
		}

		public int getM_Reservation() {
			return m_Reservation;
		}

		public void setM_Reservation(int m_Reservation) {
			this.m_Reservation = m_Reservation;
		}

		public int getM_Categorie() {
			return m_Categorie;
		}

		public void setM_Categorie(int m_Categorie) {
			this.m_Categorie = m_Categorie;
		}
		
		
}
