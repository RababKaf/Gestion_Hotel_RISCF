package MODEL;

public class ChambreReservee {
	private ReservationCh m_Reservation;
	private  Chambre  m_Chambre;
	 ChambreReservee()
	 {
		 
	 }
	 
}
